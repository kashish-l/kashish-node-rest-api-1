const axios = require('axios');
const express = require("express");
const apicache = require("apicache");

var app = express();


//configure apicache 
let cache = apicache.middleware;   
  
//caching all routes for 5 minutes
app.use(cache('5 minutes'));

app.get('/api/ping', (req, res, next) => {
    res.json({ "sucess": true }, 200);
});

app.get('/api/posts/', (req, res, next) => {
    if (req.query.tags) {

        let tags = req.query.tags.split(',');
        let err = "";
        let posts = [];

        let axiosArray = [];

        for (let i = 0; i < tags.length; i++) {

            let newPromise = axios({
                method: 'get',
                url: `https://api.hatchways.io/assessment/blog/posts?tag=${tags[i]}`
            });
            axiosArray.push(newPromise);
        }

        axios.all(axiosArray)
        .then(axios.spread((...responses) => {
            responses.forEach(res => {
                if (posts.length === 0)
                    posts.push(...res.data.posts);
                else {
                    let IDs = [];
                    posts.forEach(post => {
                        IDs.push(post.id);
                    });

                    res.data.posts.forEach(post => {
                        if (!IDs.includes(post.id))
                            posts.push(post);
                    });
                }
            });

            if (req.query.sortBy) {
                let sortBy = req.query.sortBy.toLowerCase();
                if (!['id', 'reads', 'likes', 'popularity'].includes(sortBy)) {
                    res.status(400).json(err="sortBy parameter is invalid!");
                }
                posts.sort((a, b) => {return parseFloat(a[sortBy]) - parseFloat(b[sortBy])});
            }
            
            if (req.query.direction) {
                let direction = req.query.direction.toLowerCase();
                if(direction === 'desc'){
                    posts.reverse();
                }
                else if(direction !== 'asc')
                    res.status(400).json(err="direction parameter is invalid!");
            }

            if(!err)
                res.status(200).json({"posts":posts});
        }))
        .catch(error => { res.status(400).json(err=error); })

    }
    else {
        res.status(400).json({ "error": "Tags parameter is required" });
    }

});

app.listen(3000, () => {
    console.log("Server running on port 3000");
});
