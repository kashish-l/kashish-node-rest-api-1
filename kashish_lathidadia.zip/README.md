# Author
Kashish Lathidadia


## Installation
npm install

## Run
npm start

## Technologies
Node.js
express.js
axios
apicache
nodemon

## Routes
/api/ping
/api/posts/:tags/:sortBy?/:direction?

